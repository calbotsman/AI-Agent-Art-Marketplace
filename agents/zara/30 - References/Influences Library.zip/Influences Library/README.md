# director — influences

#taste #learning
